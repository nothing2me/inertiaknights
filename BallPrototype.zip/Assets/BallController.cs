using UnityEngine;
using UnityEngine.InputSystem;

public class BallController : MonoBehaviour
{
    public float speed = 10f;
    public float jumpForce = 5f;
    public bool jumpOnSpace = true;
    public LayerMask groundLayer; // Layer(s) that are considered ground
    public LayerMask goalLayer; // Layer(s) that are considered goals
    public float groundCheckDistance = 0.55f; // Distance to check for ground below center
    public ScoreCounter scoreCounter; // Reference to the score counter UI
    public InputAction moveAction; // Define an input action for movement
    public InputAction jumpAction; // Define an input action for jumping
    private Rigidbody rb;
    private System.Collections.Generic.Dictionary<Collider, Color> originalColors = new System.Collections.Generic.Dictionary<Collider, Color>();

    void OnEnable()
    {
        // Enable the input actions when the object is enabled
        moveAction.Enable();
        jumpAction.Enable();
    }

    void OnDisable()
    {
        // Disable the input actions when the object is disabled
        moveAction.Disable();
        jumpAction.Disable();
    }

    void Start()
    {
        // Get the Rigidbody component attached to the ball
        rb = GetComponent<Rigidbody>();

        // Prevent ball from falling through floor at high speeds
        rb.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;
    }

    // FixedUpdate is used for physics calculations
    void FixedUpdate()
    {
        // Read the movement input value
        Vector2 moveInput = moveAction.ReadValue<Vector2>();

        // Get camera forward and right vectors
        Vector3 camForward = Camera.main.transform.forward;
        Vector3 camRight = Camera.main.transform.right;

        // Project vectors onto the XZ plane (ignore Y) and normalize
        camForward.y = 0;
        camRight.y = 0;
        camForward.Normalize();
        camRight.Normalize();

        // Create a movement vector based on input relative to the camera
        Vector3 movement = (camForward * moveInput.y + camRight * moveInput.x).normalized;

        // Apply force to the ball
        rb.AddForce(movement * speed);

        // Check for ground
        bool isGrounded = Physics.Raycast(transform.position, Vector3.down, groundCheckDistance, groundLayer);

        // Update HUD stats
        if (scoreCounter != null)
        {
            scoreCounter.UpdateStats(rb.linearVelocity.magnitude, isGrounded);
        }

        // Check for jump input (only if grounded)
        if (jumpOnSpace && jumpAction.triggered && isGrounded)
        {
            rb.AddForce(Vector3.up * jumpForce, ForceMode.Impulse);
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        bool isInGoalLayer = (((1 << other.gameObject.layer) & goalLayer) != 0);
        Debug.Log($"Entered trigger: {other.gameObject.name} (Layer: {LayerMask.LayerToName(other.gameObject.layer)}, Mask: {goalLayer.value}, Matches: {isInGoalLayer})");

        // Check if the collided object is in the goal layer
        if (isInGoalLayer)
        {
            Debug.Log("Goal match confirmed!");
            
            // Increment score
            if (scoreCounter != null)
            {
                scoreCounter.AddScore(1);
            }
            else
            {
                Debug.LogError("ScoreCounter reference is missing on BallController! Did you drag the ScoreCounter from the hierarchy into the Ball Inspector?");
            }

            // Visual feedback: Turn goal green and save original color
            MeshRenderer renderer = other.GetComponent<MeshRenderer>();
            if (renderer != null)
            {
                if (!originalColors.ContainsKey(other))
                {
                    originalColors[other] = renderer.material.color;
                }
                renderer.material.color = Color.green;
            }
        }
    }

    private void OnTriggerExit(Collider other)
    {
        // Revert color if it was a goal
        if (((1 << other.gameObject.layer) & goalLayer) != 0)
        {
            MeshRenderer renderer = other.GetComponent<MeshRenderer>();
            if (renderer != null && originalColors.ContainsKey(other))
            {
                renderer.material.color = originalColors[other];
                originalColors.Remove(other);
            }
        }
    }
}
