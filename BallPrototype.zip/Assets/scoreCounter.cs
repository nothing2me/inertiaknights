using UnityEngine;
using TMPro;

public class ScoreCounter : MonoBehaviour
{
    public TextMeshProUGUI scoreText;
    private int score = 0;
    private float currentSpeed = 0f;
    private bool canJump = false;

    void Start()
    {
        UpdateHUDText();
    }

    public void AddScore(int points)
    {
        score += points;
        UpdateHUDText();
    }

    public void UpdateStats(float speed, bool jumpReady)
    {
        currentSpeed = speed;
        canJump = jumpReady;
        UpdateHUDText();
    }

    private void UpdateHUDText()
    {
        if (scoreText != null)
        {
            string jumpColor = canJump ? "green" : "red";
            string jumpStatus = canJump ? "READY" : "WAIT";
            
            scoreText.text = $"Score: {score}\n" +
                             $"Speed: {currentSpeed:F2}\n" +
                             $"Jump: <color={jumpColor}>{jumpStatus}</color>";
        }
    }
}
